<?php
/**
 * @description This file has been dynamically created by ILIAS WebAccessChecker
 *
 * @author      Fabian Schmid <fs@studer-raimann.ch>
 */
$salt = 'b784fa20456268a92b3b80d8dde78b5b';
